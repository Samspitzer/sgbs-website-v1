import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle } from 'lucide-react';
import { useSmoothSnap } from '../hooks/useSmoothSnap';
import { Footer } from '../components/Footer';

type FormErrors = Partial<Record<string, string>>;

function validateForm(data: Record<string, string>): FormErrors {
  const errors: FormErrors = {};
  if (!data.name.trim()) errors.name = 'Name is required';
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Enter a valid email address';
  }
  if (data.phone && !/^[\d\s\-()+.]+$/.test(data.phone)) {
    errors.phone = 'Enter a valid phone number';
  }
  if (!data.message.trim()) errors.message = 'Message is required';
  return errors;
}

export function ContactPage() {
  const [formState, setFormState] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [errors, setErrors] = useState<FormErrors>({});
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    projectLocation: '',
    projectSize: '',
    message: '',
  });

  useSmoothSnap(1200);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (errors[name]) {
      setErrors({ ...errors, [name]: undefined });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateForm(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setFormState('submitting');
    setTimeout(() => {
      setFormState('success');
    }, 1500);
  };

  const inputClass = (field: string) =>
    `w-full px-4 py-3 bg-dark-900 border text-cream-100 placeholder-cream-100/40 focus:outline-none transition-colors ${
      errors[field] ? 'border-red-500 focus:border-red-400' : 'border-dark-600 focus:border-accent-500'
    }`;

  return (
    <div className="bg-dark-950">

      {/* ============ HERO SECTION ============ */}
      <section className="relative h-screen min-h-[700px] overflow-hidden snap-section">
        <div className="absolute inset-0">
          <div className="absolute inset-0 overflow-hidden opacity-35">
            <img
              src="/images/projects/madison-2020.jpg"
              alt=""
              className="absolute w-full h-full object-cover"
              style={{ filter: 'blur(18px)', transform: 'scale(1.2)' }}
            />
          </div>
          <div className="absolute inset-0 overflow-hidden">
            <img
              src="/images/projects/madison-2020.jpg"
              alt=""
              className="absolute w-full h-full object-cover hero-zoom"
              style={{
                objectPosition: '50% 100%',
                transformOrigin: '50% 100%',
                '--zoom-from': 1.02,
                '--zoom-to': 1.2,
                '--focus-x': '50%',
                '--y-start': '100%',
                '--y-end': '0%',
              } as React.CSSProperties}
            />
          </div>
          <div className="absolute inset-0" style={{ background: 'rgba(0, 0, 0, 0.2)' }} />
          <div className="absolute inset-0 hero-text-backdrop" />
          <div className="absolute inset-x-0 top-0 h-40 hero-top-gradient" />
        </div>

        <div className="relative h-full w-full px-8 md:px-14 lg:px-20 xl:px-24">
          <div className="flex flex-col justify-center h-full pt-20">
            <div className="max-w-3xl">
              <p className="text-accent-400 font-bold tracking-[0.2em] uppercase text-base mb-4 animate-fade-in hero-text-strong">
                Get In Touch
              </p>
              <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.1] animate-fade-in-up hero-text-strong">
                Let's Talk About<br />
                <span className="text-accent-400">Your Project</span>
              </h1>
              <p className="mt-6 text-lg lg:text-xl text-white/90 font-medium leading-relaxed max-w-lg animate-fade-in-up stagger-2 hero-text">
                Get a quote or ask a question — we respond within 24 hours.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row gap-4 animate-fade-in-up stagger-3">
                <a href="tel:845-923-2052" className="btn-primary">
                  <Phone className="w-5 h-5" /> Call 845-923-2052
                </a>
                <a href="mailto:sales@sgbsny.com" className="btn-outline">
                  <Mail className="w-5 h-5" /> Email Us
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ CONTACT INFO + FORM ============ */}
      <section className="h-screen flex items-center snap-section bg-dark-900 relative overflow-hidden noise-overlay">
        <div className="container-custom relative w-full">
          <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">

            {/* Contact Info */}
            <div className="lg:col-span-2 animate-fade-in-up">
              <div className="line-accent mb-5" />
              <h2 className="font-display text-3xl md:text-4xl font-bold text-cream-100 mb-3">
                Contact Info
              </h2>
              <p className="text-cream-100/70 text-base mb-8">
                Ready to start your project? Reach out anytime.
              </p>

              <div className="space-y-5">
                <a
                  href="https://maps.google.com/?q=200+NY-17M+Harriman+NY"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-4 group"
                >
                  <div className="w-11 h-11 flex-shrink-0 flex items-center justify-center bg-dark-800 border border-dark-600 group-hover:border-accent-500/50 transition-colors">
                    <MapPin className="w-5 h-5 text-accent-400" />
                  </div>
                  <div>
                    <div className="text-xs text-cream-100/50 uppercase tracking-wide">Location</div>
                    <div className="mt-1 text-cream-100 text-sm group-hover:text-accent-400 transition-colors">
                      200 NY-17M, Harriman, NY 10926
                    </div>
                  </div>
                </a>

                <a href="tel:845-923-2052" className="flex items-start gap-4 group">
                  <div className="w-11 h-11 flex-shrink-0 flex items-center justify-center bg-dark-800 border border-dark-600 group-hover:border-accent-500/50 transition-colors">
                    <Phone className="w-5 h-5 text-accent-400" />
                  </div>
                  <div>
                    <div className="text-xs text-cream-100/50 uppercase tracking-wide">Phone</div>
                    <div className="mt-1 text-cream-100 text-sm group-hover:text-accent-400 transition-colors">
                      845-923-2052
                    </div>
                  </div>
                </a>

                <a href="mailto:sales@sgbsny.com" className="flex items-start gap-4 group">
                  <div className="w-11 h-11 flex-shrink-0 flex items-center justify-center bg-dark-800 border border-dark-600 group-hover:border-accent-500/50 transition-colors">
                    <Mail className="w-5 h-5 text-accent-400" />
                  </div>
                  <div>
                    <div className="text-xs text-cream-100/50 uppercase tracking-wide">Email</div>
                    <div className="mt-1 text-cream-100 text-sm group-hover:text-accent-400 transition-colors">
                      sales@sgbsny.com
                    </div>
                  </div>
                </a>

                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 flex-shrink-0 flex items-center justify-center bg-dark-800 border border-dark-600">
                    <Clock className="w-5 h-5 text-accent-400" />
                  </div>
                  <div>
                    <div className="text-xs text-cream-100/50 uppercase tracking-wide">Hours</div>
                    <div className="mt-1 text-cream-100 text-sm">
                      Mon – Fri: 7AM – 5PM
                    </div>
                  </div>
                </div>
              </div>

              {/* Google Maps Embed */}
              <div className="mt-6 overflow-hidden border border-dark-600" style={{ height: '180px' }}>
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2998.5!2d-74.1455!3d41.3025!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2e3a5c6b1234%3A0x0!2s200+NY-17M%2C+Harriman%2C+NY+10926!5e0!3m2!1sen!2sus!4v1700000000000"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="S&G Builders Supply Location"
                />
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-3 animate-fade-in-up stagger-1">
              <div className="bg-dark-800 border border-dark-700 p-6 lg:p-8">
                <h3 className="text-xl font-semibold text-cream-100 mb-1">
                  Request a Quote
                </h3>
                <p className="text-cream-100/60 text-sm mb-6">
                  Fill out the form and we'll get back to you within 24 hours.
                </p>

                {formState === 'success' ? (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 mx-auto bg-accent-500/10 rounded-full flex items-center justify-center mb-6">
                      <CheckCircle className="w-8 h-8 text-accent-400" />
                    </div>
                    <h4 className="text-2xl font-semibold text-cream-100 mb-2">
                      Thank You!
                    </h4>
                    <p className="text-cream-100/70">
                      We've received your message and will be in touch shortly.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="name" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                          Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          className={inputClass('name')}
                          placeholder="Your name"
                        />
                        {errors.name && <p className="mt-1 text-red-400 text-xs">{errors.name}</p>}
                      </div>
                      <div>
                        <label htmlFor="company" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                          Company
                        </label>
                        <input
                          type="text"
                          id="company"
                          name="company"
                          value={formData.company}
                          onChange={handleChange}
                          className={inputClass('company')}
                          placeholder="Company name"
                        />
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="email" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                          Email *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          className={inputClass('email')}
                          placeholder="email@company.com"
                        />
                        {errors.email && <p className="mt-1 text-red-400 text-xs">{errors.email}</p>}
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                          Phone
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          className={inputClass('phone')}
                          placeholder="(555) 555-5555"
                        />
                        {errors.phone && <p className="mt-1 text-red-400 text-xs">{errors.phone}</p>}
                      </div>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="projectLocation" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                          Project Location
                        </label>
                        <input
                          type="text"
                          id="projectLocation"
                          name="projectLocation"
                          value={formData.projectLocation}
                          onChange={handleChange}
                          className={inputClass('projectLocation')}
                          placeholder="City, State"
                        />
                      </div>
                      <div>
                        <label htmlFor="projectSize" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                          Project Size
                        </label>
                        <select
                          id="projectSize"
                          name="projectSize"
                          value={formData.projectSize}
                          onChange={handleChange}
                          className={inputClass('projectSize')}
                        >
                          <option value="">Select size...</option>
                          <option value="1-50">1 - 50 Units</option>
                          <option value="51-100">51 - 100 Units</option>
                          <option value="101-200">101 - 200 Units</option>
                          <option value="201-500">201 - 500 Units</option>
                          <option value="500+">500+ Units</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-xs font-medium text-cream-100/80 mb-1.5">
                        Message *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows={4}
                        value={formData.message}
                        onChange={handleChange}
                        className={`${inputClass('message')} resize-none`}
                        placeholder="Tell us about your project, timeline, and what you need..."
                      />
                      {errors.message && <p className="mt-1 text-red-400 text-xs">{errors.message}</p>}
                    </div>

                    <button
                      type="submit"
                      disabled={formState === 'submitting'}
                      className="w-full py-3.5 bg-accent-500 text-white font-semibold tracking-wide uppercase hover:bg-accent-400 transition-colors disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {formState === 'submitting' ? (
                        <>
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          Submit Request <Send className="w-5 h-5" />
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ CTA + FOOTER ============ */}
      <Footer isSnapSection />
    </div>
  );
}
