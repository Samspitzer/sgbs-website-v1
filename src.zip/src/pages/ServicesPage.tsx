import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { services, products } from '../data/services';
import { ImageWithFallback, stripExtension } from '../components/ImageWithFallback';
import { useSmoothSnap } from '../hooks/useSmoothSnap';
import { Footer } from '../components/Footer';

const processSteps = [
  { step: '01', title: 'Estimating & Bidding', description: 'Accurate, competitive bids with detailed breakdowns from your plans.' },
  { step: '02', title: 'Field Measurement', description: 'On-site measurements to confirm all dimensions and technical details.' },
  { step: '03', title: 'Shop Drawings', description: 'Detailed drawings coordinated with architects and GCs for approval.' },
  { step: '04', title: 'Manufacturing', description: 'Coordinated procurement ensuring materials arrive on your schedule.' },
  { step: '05', title: 'Delivery & Install', description: 'Supervised deliveries and professional installation in the tristate area.' },
  { step: '06', title: 'Punch List', description: 'We stay until every door and piece of hardware is perfect.' },
];

export function ServicesPage() {
  const [activeService, setActiveService] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useSmoothSnap(1200);

  const goToService = useCallback((index: number) => {
    setActiveService(((index % services.length) + services.length) % services.length);
  }, []);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setActiveService(prev => (prev + 1) % services.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [isPaused]);

  const current = services[activeService];
  const Icon = current.icon;

  return (
    <div className="bg-dark-950">

      {/* ============ HERO SECTION ============ */}
      <section className="relative h-screen min-h-[700px] overflow-hidden snap-section flex items-end">
        <div className="absolute inset-0">
          <div className="absolute inset-0 overflow-hidden opacity-35">
            <img
              src="/images/backgrounds/services.jpg"
              alt=""
              className="absolute w-full h-full object-cover"
              style={{ filter: 'blur(18px)', transform: 'scale(1.2)' }}
            />
          </div>
          <div className="absolute inset-0 overflow-hidden">
            <img
              src="/images/backgrounds/services.jpg"
              alt=""
              className="absolute w-full h-full object-cover hero-zoom-slow"
              style={{
                objectPosition: '50% 50%',
                transformOrigin: '50% 50%',
                '--zoom-from': 1.1,
                '--zoom-to': 1.03,
                '--focus-x': '50%',
                '--y-start': '30%',
                '--y-end': '50%',
              } as React.CSSProperties}
            />
          </div>
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.3) 40%, rgba(0,0,0,0.6) 80%, rgba(0,0,0,0.85) 100%)' }} />
          <div className="absolute inset-0 hero-text-backdrop" />
          <div className="absolute inset-x-0 top-0 h-40 hero-top-gradient" />
        </div>

        <div className="relative z-10 container-custom pb-20 lg:pb-28">
          <div className="max-w-3xl">
            <p className="text-accent-400 font-bold tracking-[0.2em] uppercase text-sm mb-4 animate-fade-in hero-text-strong">
              What We Do
            </p>
            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.1] animate-fade-in-up hero-text-strong">
              Full-Service Door &amp;<br />
              <span className="text-accent-400">Hardware Solutions</span>
            </h1>
            <p className="mt-6 text-lg lg:text-xl text-white/90 font-medium leading-relaxed max-w-xl animate-fade-in-up stagger-2 hero-text">
              From initial estimating through final punch list, we handle every phase of your door, hardware, and millwork scope.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4 animate-fade-in-up stagger-3">
              <Link to="/contact" className="btn-primary">
                Get a Quote <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/projects" className="btn-outline">
                View Projects
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ============ SERVICES SHOWCASE ============ */}
      <section
        className="h-screen flex items-center snap-section relative overflow-hidden"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        <div className="absolute inset-0 overflow-hidden">
          <ImageWithFallback
            basePath={stripExtension(current.image)}
            alt=""
            className="w-full h-full object-cover transition-opacity duration-700"
            style={{ filter: 'blur(2px)', transform: 'scale(1.05)', objectPosition: 'center 30%' }}
          />
          <div
            className="absolute inset-0"
            style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.7) 45%, rgba(0,0,0,0.4) 100%)' }}
          />
        </div>

        <div className="container-custom relative w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div>
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 flex items-center justify-center bg-accent-500 text-white transition-all duration-500">
                  <Icon className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-accent-400 text-xs font-bold tracking-[0.2em] uppercase">
                    Service {activeService + 1} of {services.length}
                  </p>
                </div>
              </div>
              <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-cream-100 mb-6" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.8)' }}>
                {current.title}
              </h2>
              <p className="text-cream-100/80 text-lg leading-relaxed max-w-lg" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
                {current.description}
              </p>

              {/* Navigation */}
              <div className="mt-10 flex items-center gap-4">
                <button
                  onClick={() => goToService(activeService - 1)}
                  className="w-12 h-12 flex items-center justify-center border border-dark-600 text-cream-100/70 hover:border-accent-500 hover:text-accent-400 transition-all duration-300"
                  aria-label="Previous service"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => goToService(activeService + 1)}
                  className="w-12 h-12 flex items-center justify-center border border-dark-600 text-cream-100/70 hover:border-accent-500 hover:text-accent-400 transition-all duration-300"
                  aria-label="Next service"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <div className="flex gap-2 ml-4">
                  {services.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => goToService(i)}
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        i === activeService ? 'w-8 bg-accent-500' : 'w-3 bg-dark-600 hover:bg-dark-500'
                      }`}
                      aria-label={`Go to service ${i + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Service Image */}
            <div className="hidden lg:block">
              <div className="relative overflow-hidden" style={{ borderRadius: '8px' }}>
                <ImageWithFallback
                  basePath={stripExtension(current.image)}
                  alt={current.title}
                  className="w-full aspect-[4/3] object-cover"
                  style={{ objectPosition: 'center 30%' }}
                />
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 40%)' }}
                />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-xl font-semibold text-accent-400 hero-text-strong">{current.title}</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ PRODUCT CATEGORIES ============ */}
      <section className="h-screen flex items-center snap-section relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <img
            src="/images/backgrounds/cta.jpeg"
            alt=""
            className="w-full h-full object-cover"
            style={{ filter: 'blur(3px)', transform: 'scale(1.05)' }}
          />
          <div
            className="absolute inset-0"
            style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0.7) 50%, rgba(0,0,0,0.8) 100%)' }}
          />
        </div>

        <div className="container-custom relative">
          <div className="text-center max-w-2xl mx-auto mb-12 animate-fade-in-up">
            <div className="line-accent mx-auto mb-6" />
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-cream-100" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.8)' }}>
              Product Categories
            </h2>
            <p className="mt-4 text-cream-100/70 text-lg" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
              A complete range of doors, frames, hardware, and millwork for residential and commercial projects.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 animate-fade-in-up stagger-2">
            {products.map((product) => (
              <div
                key={product.id}
                className="group relative overflow-hidden transition-all duration-300 hover:-translate-y-1"
                style={{
                  borderRadius: '8px',
                  border: '1px solid rgba(255,255,255,0.08)',
                  background: 'rgba(10,10,10,0.7)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <div className="p-7">
                  <div
                    className="w-10 h-10 flex items-center justify-center mb-5 transition-all duration-300 group-hover:bg-accent-500"
                    style={{ background: 'rgba(139, 26, 26, 0.15)' }}
                  >
                    <div className="w-2.5 h-2.5 bg-accent-400 group-hover:bg-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-lg font-semibold text-cream-100 mb-2">
                    {product.title}
                  </h3>
                  <p className="text-cream-100/50 leading-relaxed text-sm">
                    {product.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ OUR PROCESS ============ */}
      <section className="h-screen flex items-center snap-section bg-dark-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.03]">
          <div className="absolute inset-0" style={{ backgroundImage: 'repeating-linear-gradient(90deg, rgba(255,255,255,0.03) 0px, transparent 1px, transparent 60px)', backgroundSize: '60px 60px' }} />
        </div>

        <div className="container-custom relative">
          <div className="text-center max-w-2xl mx-auto mb-12 animate-fade-in-up">
            <div className="line-accent mx-auto mb-6" />
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-cream-100">
              Our Process
            </h2>
            <p className="mt-4 text-cream-100/70 text-lg">
              A streamlined approach refined over years of experience.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in-up stagger-2">
            {processSteps.map((item) => (
              <div key={item.step} className="group flex gap-5 p-6 bg-dark-800/50 border border-dark-700 hover:border-accent-500/50 transition-all duration-300">
                <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center border border-accent-500/50 text-accent-400 font-display font-bold text-sm bg-dark-900 group-hover:bg-accent-500 group-hover:text-white group-hover:border-accent-500 transition-all duration-300">
                  {item.step}
                </div>
                <div>
                  <h3 className="text-base font-semibold text-cream-100 group-hover:text-accent-400 transition-colors duration-300">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 text-cream-100/50 leading-relaxed text-sm">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ CTA + FOOTER ============ */}
      <Footer isSnapSection />
    </div>
  );
}

export default ServicesPage;
