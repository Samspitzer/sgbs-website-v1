import { useState, useMemo, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { projects, categories } from '../data/projects';
import { stats } from '../data/services';
import { useSmoothSnap } from '../hooks/useSmoothSnap';
import { Footer } from '../components/Footer';

export function ProjectsPage() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [spotlightIndex, setSpotlightIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useSmoothSnap(1200);

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'all') return projects;
    return projects.filter((p) => p.category === activeCategory);
  }, [activeCategory]);

  const goToSpotlight = useCallback((index: number) => {
    setSpotlightIndex(((index % projects.length) + projects.length) % projects.length);
  }, []);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setSpotlightIndex(prev => (prev + 1) % projects.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [isPaused]);

  const spotlightProject = projects[spotlightIndex];

  return (
    <div className="bg-dark-950">

      {/* ============ HERO SECTION ============ */}
      <section className="relative h-screen min-h-[700px] overflow-hidden snap-section">
        <div className="absolute inset-0">
          <div className="absolute inset-0 overflow-hidden opacity-35">
            <img
              src="/images/projects/allure-258.jpeg"
              alt=""
              className="absolute w-full h-full object-cover"
              style={{ filter: 'blur(18px)', transform: 'scale(1.2)' }}
            />
          </div>
          <div className="absolute inset-0 overflow-hidden">
            <img
              src="/images/projects/allure-258.jpeg"
              alt=""
              className="absolute w-full h-full object-cover hero-zoom"
              style={{
                objectPosition: '50% 50%',
                transformOrigin: '50% 50%',
                '--zoom-from': 1.1,
                '--zoom-to': 1.03,
                '--focus-x': '50%',
                '--y-start': '50%',
                '--y-end': '50%',
              } as React.CSSProperties}
            />
          </div>
          <div className="absolute inset-0" style={{ background: 'rgba(0, 0, 0, 0.3)' }} />
          <div className="absolute inset-0 hero-text-backdrop" />
          <div className="absolute inset-x-0 top-0 h-40 hero-top-gradient" />
        </div>

        <div className="relative h-full w-full px-8 md:px-14 lg:px-20 xl:px-24">
          <div className="flex flex-col justify-center h-full pt-20">
            <div className="max-w-3xl">
              <p className="text-accent-400 font-bold tracking-[0.2em] uppercase text-base mb-4 animate-fade-in hero-text-strong">
                Our Portfolio
              </p>
              <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.1] animate-fade-in-up hero-text-strong">
                Projects Across<br />
                <span className="text-accent-400">The Nation</span>
              </h1>
              <p className="mt-6 text-lg lg:text-xl text-white/90 font-medium leading-relaxed max-w-lg animate-fade-in-up stagger-2 hero-text">
                A sample of recent multifamily and commercial work across the Northeast and beyond.
              </p>

              {/* Inline Stats */}
              <div className="mt-10 flex flex-wrap gap-8 animate-fade-in-up stagger-3">
                {stats.map((stat) => (
                  <div key={stat.label} className="hero-text-strong">
                    <div className="text-3xl font-display font-bold text-accent-400">{stat.value}</div>
                    <div className="text-white/70 text-sm uppercase tracking-wide">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ PROJECTS GALLERY ============ */}
      <section className="h-screen flex flex-col justify-center snap-section bg-dark-900 relative overflow-hidden noise-overlay">
        <div className="container-custom relative w-full">
          {/* Header + Filters */}
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8">
            <div className="animate-fade-in-up">
              <div className="line-accent mb-4" />
              <h2 className="font-display text-3xl md:text-4xl font-bold text-cream-100">
                Project Gallery
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-4 md:mt-0 animate-fade-in-up stagger-1">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-5 py-2 text-xs font-semibold tracking-wide uppercase transition-all duration-300 ${
                    activeCategory === cat.id
                      ? 'bg-accent-500 text-white'
                      : 'bg-dark-800 text-cream-100/70 border border-dark-600 hover:border-accent-500/50 hover:text-cream-100'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 animate-fade-in-up stagger-2">
            {filteredProjects.slice(0, 6).map((project) => (
              <article
                key={project.id}
                className="group relative overflow-hidden card-hover"
                style={{ borderRadius: '4px' }}
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.name}
                    className="w-full h-full object-cover card-image transition-transform duration-700"
                    loading="lazy"
                  />
                </div>

                <div className="absolute inset-0 card-overlay-gallery opacity-80 group-hover:opacity-90 transition-opacity duration-300" />
                <div className="absolute inset-0 bg-accent-500/0 group-hover:bg-accent-500/10 transition-colors duration-300" />

                <div className="absolute inset-0 p-5 flex flex-col justify-end">
                  <p className="text-accent-400 text-xs font-semibold tracking-wide uppercase mb-1">
                    {project.units}
                  </p>
                  <h3 className="text-xl font-display font-semibold text-cream-100 mb-0.5">
                    {project.name}
                  </h3>
                  <p className="text-cream-100/70 text-sm">
                    {project.location}
                  </p>
                  {project.description && (
                    <p className="mt-2 text-cream-100/60 text-xs leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      {project.description}
                    </p>
                  )}
                </div>
              </article>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-16">
              <p className="text-cream-100/60 text-lg">No projects found in this category.</p>
            </div>
          )}

          {filteredProjects.length > 6 && (
            <div className="text-center mt-6">
              <p className="text-cream-100/50 text-sm">
                Showing 6 of {filteredProjects.length} projects
              </p>
            </div>
          )}
        </div>
      </section>

      {/* ============ FEATURED PROJECT SPOTLIGHT ============ */}
      <section
        className="h-screen flex items-center snap-section relative overflow-hidden"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        <div className="absolute inset-0 overflow-hidden">
          <img
            key={spotlightProject.id}
            src={spotlightProject.image}
            alt=""
            className="w-full h-full object-cover transition-opacity duration-700"
            style={{ filter: 'blur(1px)', transform: 'scale(1.05)' }}
          />
          <div
            className="absolute inset-0"
            style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.6) 50%, rgba(0,0,0,0.4) 100%)' }}
          />
        </div>

        <div className="container-custom relative w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div>
              <p className="text-accent-400 text-xs font-bold tracking-[0.2em] uppercase mb-4 hero-text-strong">
                Featured Project
              </p>
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-cream-100 mb-4 hero-text-strong">
                {spotlightProject.name}
              </h2>
              <div className="flex items-center gap-4 mb-6">
                <span className="text-cream-100/80 text-lg hero-text" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
                  {spotlightProject.location}
                </span>
                <span className="text-accent-400 font-semibold hero-text-strong">
                  {spotlightProject.units}
                </span>
              </div>
              {spotlightProject.description && (
                <p className="text-cream-100/70 text-lg leading-relaxed max-w-lg mb-8 hero-text" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}>
                  {spotlightProject.description}
                </p>
              )}

              {/* Navigation */}
              <div className="flex items-center gap-4">
                <button
                  onClick={() => goToSpotlight(spotlightIndex - 1)}
                  className="w-12 h-12 flex items-center justify-center border border-white/20 text-cream-100/70 hover:border-accent-500 hover:text-accent-400 transition-all duration-300"
                  aria-label="Previous project"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => goToSpotlight(spotlightIndex + 1)}
                  className="w-12 h-12 flex items-center justify-center border border-white/20 text-cream-100/70 hover:border-accent-500 hover:text-accent-400 transition-all duration-300"
                  aria-label="Next project"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <div className="flex gap-2 ml-4">
                  {projects.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => goToSpotlight(i)}
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        i === spotlightIndex ? 'w-8 bg-accent-500' : 'w-3 bg-white/20 hover:bg-white/40'
                      }`}
                      aria-label={`Go to project ${i + 1}`}
                    />
                  ))}
                </div>
              </div>

              <div className="mt-10">
                <Link to="/contact" className="btn-primary">
                  Start Your Project <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
            </div>

            {/* Project Image */}
            <div className="hidden lg:block">
              <div className="relative overflow-hidden" style={{ borderRadius: '8px' }}>
                <img
                  src={spotlightProject.image}
                  alt={spotlightProject.name}
                  className="w-full aspect-[4/3] object-cover"
                />
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 40%)' }}
                />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="text-accent-400 font-semibold text-lg hero-text-strong">{spotlightProject.name}</p>
                  <p className="text-cream-100/70 text-sm hero-text">{spotlightProject.location} &middot; {spotlightProject.units}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ CTA + FOOTER ============ */}
      <Footer isSnapSection />
    </div>
  );
}
